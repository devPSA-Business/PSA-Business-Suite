import { useState } from 'react';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../../shared/api/firebase';
import { InstallPWAButton } from '../../shared/components/InstallPWAButton';
import { useToastStore } from '../../shared/store/toastStore';
import { ShieldAlert, ShieldCheck, Mail } from 'lucide-react';

const googleAuthProvider = new GoogleAuthProvider();

const ALLOWED_EMAILS = ['dev.psajewelry@gmail.com', 'email.kasir@gmail.com', 'email.owner@gmail.com'];

export function GatekeeperPage() {
  const { addToast } = useToastStore();
  const [isVerified, setIsVerified] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  const handleVerify = async () => {
    setIsVerifying(true);
    try {
      const result = await signInWithPopup(auth, googleAuthProvider);
      const email = result.user.email;
      
      if (!email || !ALLOWED_EMAILS.includes(email)) {
        addToast('Akun tidak terdaftar di whitelist.', 'error');
        await auth.signOut();
        setIsVerified(false);
      } else {
        addToast(`Selamat datang, ${email}`, 'success');
        setUserEmail(email);
        setIsVerified(true);
        await auth.signOut();
      }
    } catch (error) {
      addToast(error instanceof Error ? error.message : 'Terjadi kesalahan saat verifikasi', 'error');
      setIsVerified(false);
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-6">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-xl overflow-hidden">
        {/* Header Section */}
        <div className="bg-brand-900 p-8 text-center">
          <div className="mx-auto w-20 h-20 bg-gold-500 rounded-full flex items-center justify-center shadow-[0_0_20px_var(--color-gold-500)] mb-4">
            <span className="text-brand-900 text-3xl font-black tracking-tighter">PSA</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Portal Distribusi Internal</h1>
          <p className="text-gold-200 mt-2 text-sm font-medium">PSA Business Suite v1.5.0+</p>
        </div>

        {/* Content Section */}
        <div className="p-8">
          {!isVerified ? (
            <div className="space-y-6">
              <div className="flex flex-col items-center text-center space-y-3 bg-red-50 p-4 rounded-2xl border border-red-100">
                <ShieldAlert className="w-10 h-10 text-red-500" />
                <p className="text-sm text-red-800 font-medium">
                  Website ini diproteksi. Operasional kasir hanya dapat diakses melalui mode PWA Standalone (Home Screen).
                </p>
              </div>

              <button
                disabled={isVerifying}
                onClick={handleVerify}
                className="w-full flex items-center justify-center gap-3 bg-brand-900 hover:bg-brand-800 text-gold-500 py-4 px-6 rounded-2xl font-bold text-lg transition-all active:scale-95 disabled:opacity-70"
              >
                {isVerifying ? (
                  <span className="animate-pulse">Memverifikasi...</span>
                ) : (
                  <>
                    <Mail className="w-6 h-6" />
                    <span>Verifikasi Akses via Google</span>
                  </>
                )}
              </button>
            </div>
          ) : (
             <div className="space-y-8">
              <div className="flex flex-col items-center text-center space-y-3 bg-green-50 p-6 rounded-2xl border border-green-100">
                <ShieldCheck className="w-12 h-12 text-green-600" />
                <div>
                    <p className="text-sm text-green-800 font-semibold mb-1">Akses Diizinkan</p>
                    <p className="text-xs text-green-600">{userEmail}</p>
                </div>
              </div>

              <div className="space-y-4">
                  <p className="text-center text-gray-600 text-sm font-medium">
                    Silakan install aplikasi ini ke perangkat Anda untuk memulai operasional.
                  </p>
                  <InstallPWAButton />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
