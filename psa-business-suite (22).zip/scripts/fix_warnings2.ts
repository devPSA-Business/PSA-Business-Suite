import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'src/infrastructure/services/sync/SyncConflictHandler.ts');
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace(/\/\*\*[\s\S]*?type ConflictPayload[^;]+;/g, '');
fs.writeFileSync(filePath, content, 'utf-8');
