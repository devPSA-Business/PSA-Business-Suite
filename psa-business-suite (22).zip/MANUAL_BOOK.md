# MANUAL BOOK & DOKUMENTASI SISTEM KOMPREHENSIF
# PSA Business Suite (v1.5.0) — Single Source of Truth (SSOT)

> **Dokumentasi ini dirancang khusus untuk:**
> 1. **Manusia (Owner, Developer, & IT Admin):** Sebagai rujukan teknis cepat, panduan operasional, dan manual kepatuhan.
> 2. **AI Agents (Gemini, Claude, GPT, Antigravity):** Sebagai landasan pengetahuan sistem (*Context Window*) agar AI dapat memahami secara mendalam struktur kode, logika transaksional, skema penyimpanan, dan batasan audit tanpa perlu melakukan analisis ulang yang repetitif.

---

## 1. EXECUTIVE SUMMARY & PROJECT VISION

### 1.1 Deskripsi & Tujuan Utama
**PSA Business Suite (v1.5.0)** adalah sistem operasi bisnis (Enterprise Resource Planning, Point of Sale, & Customer Relationship Management) terintegrasi yang dirancang khusus untuk operasional toko perhiasan imitasi ritel dan pengelolaan aset emas. 

Aplikasi ini mengadopsi fungsionalitas **Offline-First PWA (Progressive Web Application)** yang kokoh. Sistem dirancang untuk menjamin kestabilan transaksi tanpa gangguan meskipun jaringan internet setempat terputus (*Drop-connection resilient*), mencatat transaksi secara instan (< 1 detik di tablet kasir), dan menyajikan laporan keuangan yang mutlak akurat tanpa memerlukan pemeliharaan teknis harian (*zero-maintenance*).

### 1.2 Target Pengguna (Roles & Capabilities)
1. **Kasir / Staf Frontline:**
   - Membuka dan menutup shift kasir harian.
   - Melakukan checkout penjualan ritel (B2C), penangguhan cart, melacak poin loyalitas pelanggan, serta pencatatan perbaikan barang perhiasan (Reparasi/Sepuh/Patri).
   - Memproses penerimaan buyback emas dari pelanggan dan melakukan penimbangan menggunakan timbangan asinkron terintegrasi.
2. **Manajer / Supervisor:**
   - Memberikan otorisasi modifikasi harga acuan yang kedaluwarsa (> 2 jam).
   - Mengotorisasi rekonsiliasi kasian shift jika terjadi selisih kas fisik di atas batas toleransi yang ditentukan.
   - Mengakses menu resolusi konflik data desentralisasi.
3. **Owner / Eksekutif:**
   - Memantau dasbor performa keuangan (Omset, Laba Kotor, Mutasi Kas) secara real-time.
   - Mengaudit kesesuaian rantai data transaksi (*hashing chain check*) harian.
   - Mengakses log audit forensik yang terenkripsi dan mutlak kebal modifikasi (*immutable logs*).

### 1.3 High-Level Value Proposition
- **100% Offline Operational Autonomy:** Kasir dapat beroperasi dan menyelesaikan transaksi secara luring penuh. Sinkronisasi data di latar belakang berjalan secara transparan ketika internet pulih kembali menggunakan antrean relasional IndexedDB.
- **Kriptografi Mutlak & Pelacakan Forensik:** Menyimpan data sensitif dan logs menggunakan mekanisme rantai enkripsi SHA-256 yang saling menunjuk ke blok sebelumnya, mirip arsitektur blockchain.
- **Akurasi Finansial Presisi Tinggi:** Menggunakan penanganan tipe desimal `Decimal.js` untuk mengeliminasi kesalahan pembulatan matematis JavaScript (*floating-point loss*) di setiap mutasi kas, stok, dan gramasi emas.

---

## 2. SYSTEM ARCHITECTURE & TECHNICAL STACK

### 2.1 Technical Stack
Sistem dibangun di atas fondasi teknologi berkinerja tinggi, berjenis monolit modern, dengan pemisahan keprihatinan (*Separation of Concerns*):

*   **Frontend Framework:** React 19 dengan TypeScript (v6.0) yang dikompilasi super cepat menggunakan Vite 8.
*   **State Management:**
    *   **Zustand (v5.0):** State reaktif global di memori untuk otentikasi, manajemen toast, konfigurasi visual, dan status keamanan.
    *   **Dexie React Hooks:** Untuk membaca status database luring secara reaktif langsung dari memori terindeks.
*   **Database Penjelajah (Local Master Source of Truth):** `Dexie.js` (wrapper modern di atas IndexedDB) dengan dukungan ACID transaksional lokal penuh.
*   **Database Cloud & Sinkronisasi:** Firebase Firestore (BaaS) & Firebase Auth (Otorisasi Terpusat).
*   **Keamanan Kriptografis lokal:** Web Crypto API (untuk hashing pbkdf2 asinkron lokal) dan KMS Service.
*   **Routing:** TanStack Router (Penyedia navigasi yang type-safe).
*   **Styling:** Tailwind CSS v4 (Sistem desain utilitas hulu-ke-hilir) dengan animasi transisi mikro berbasis `Motion` (Framer).
*   **Hardware Interfacing:** WebUSB & Web Bluetooth API untuk komunikasi langsung asinkron dengan Timbangan Emas (Gold Scale) dan Printer Kasir Thermal.

### 2.2 Arsitektur Komponen (Data Flow & Domain-Driven Design)
Aplikasi ini diorganisasikan menggunakan kerangka **Feature-Sliced Design (FSD)** yang dikombinasikan dengan prinsip **Clean Architecture**:

```
+----------------------------------------------------------------------------+
|                          CLIENT BROWSER / PWA TABS                         |
|                                                                            |
|   [UI Layer / Features]                                                    |
|   pos/ | gold/ | inventory/ | shift/ | reports/                            |
|             |                                                              |
|             v                                                              |
|   [Application Services / Use Cases]                                       |
|   CheckoutUseCase | CloseShiftUseCase | AuditIntegrityService              |
|             |                                                              |
|             v                                                              |
|   [Domain Contracts & Repositories]                                        |
|   ICustomerRepository | IStockRepository | IUnitOfWork                     |
|             |                                                              |
+-------------|--------------------------------------------------------------+
              | (Local Write with ACID Tx via Dexie)
              v
+------------------------------------+      (Online Sync Event Triggered)
|  LOCAL STORAGE (SSoT)              |===============> [SyncServiceImpl]
|  Dexie.js IndexedDB PSA_POS_DB     |                       │
+------------------------------------+                       │ (Masks PII via Regex)
                                                             v
+------------------------------------+             +-------------------+
|  BFF BACKEND (Vercel/Serverless)   |             | CLOUD STORAGE     |
|  /api/hash-pin                     |             | Firebase Database |
|  /api/ask-gemini (PII Encrypted)   |             | (Double Verified) |
|  /api/telegram-alert               |             +-------------------+
+------------------------------------+
```

1.  **Lokal Pertama (IndexedDB SSoT):** Segala bentuk mutasi data (transaksi, penyesuaian stok, petty cash, perubahan shift) wajib ditulis ke `Dexie` lokal melalui modul `UnitOfWorkImpl` terlebih dahulu. Aplikasi tidak menunggu kembalian respons server internet untuk melanjutkan aktivitas operasional kasir.
2.  **Antrean Sinkronisasi (Sync Queue):** Setiap kali `UnitOfWork` melakukan komit data secara ACID ke IndexedDB, pemicu data mendaftarkan entri transaksional baru ke tabel `sync_events` dengan status `PENDING`.
3.  **Guardian Sync (`SyncServiceImpl`):** Berjalan di latar belakang, memonitor status internet (`navigator.onLine`). Begitu terhubung, ia memproses antrean `sync_events` secara berurutan sesuai urutan kronologis pendaftaran (*chronological FIFO*). Data dikirim ke cloud Firebase dengan `idempotency_key` untuk mencegah pembuatan entri ganda jika koneksi putus di tengah jalan.
4.  **BFF Proxy Layer (`/api/*`):** Menyediakan enkapsulasi kriptografis (perhiasan password menggunakan sandi rahasia server) dan sanitasi PII (Personally Identifiable Information) agar data mentah tidak bocor ke luar.

---

## 3. FUNCTIONAL SPECIFICATIONS (DETAIL FITUR)

### 3.1 Morning Readiness Check (SOP Awal Hari)
*   **Tujuan:** Memandu personil kasir melakukan pemeriksaan mandiri terhadap hardware toko fisik sebelum diperbolehkan melayani transaksi pertama.
*   **Pemeriksaan Hardware:**
    1.  **Printer Thermal:** Melakukan uji cetak slip ringkas standar.
    2.  **Cash Drawer (Laci Uang Elektrik):** Mengirim sinyal pemicu asinkron untuk memastikan laci dapat membuka otomatis.
    3.  **Timbangan Emas (Scale):** Menghubungi port serial USB timbangan dan mengecek kestabilan nilai pembacaan angka nol.
*   **Aturan Bisnis Pembuka (Soft-Blocker):**
    - Fitur ini merupakan alat bantu disiplin psikologis kasir, **bukan fungsi pemblokiran permanen**.
    - Tombol **"Lewati & Buka Shift"** selamanya aktif dalam keadaan darurat atau jika toko tidak dilengkapi hardware periferal di atas.
    - Setiap melewati langkah pemeriksaan, sistem mengirimkan log audit dengan tipe entri `HARDWARE_READINESS_SKIPPED` yang mencatat detail perangkat spesifik mana yang dilewati untuk dianalisis oleh Owner.

### 3.2 Point of Sale (POS) & Checkout
*   **Kontrol Keranjang (Cart Display):**
    - Menempelkan produk ke keranjang belanja menggunakan pencarian manual cepat, filter kategori, atau pemindaian asinkron barcode (`html5-qrcode`).
    - Mendukung penangguhan belanjaan (`suspended_carts`). Piringan belanjaan kasir dapat disimpan sementara saat pelanggan mencari barang tambahan, lalu ditarik kembali sewaktu-waktu.
*   **Skema Penentuan Harga:**
    - Harga ritel standar diambil langsung dari katalog inventori lokal.
    - Integrasi program loyalitas: hitung total akumulasi poin (`loyaltyPoints`) pelanggan. Poin dapat digunakan sebagai kontributor potongan harga di luar diskon manual biasa.
*   **Metode Pembayaran:** Tunai (Cash), QRIS, Transfer Bank, atau Pembayaran Gabungan (Split Payment).
*   **Akurasi Transaksi Atomik:** Mutasi stok barang ritel dan data penjualan ritel berada di bawah naungan transaksi tunggal. Pembatalan penjualan (VOID) membutuhkan PIN otorisasi Manager untuk mencegah pembuangan stok secara ilegal.

### 3.3 Buyback Emas & Forensik Treasury
*   **Tujuan:** Membeli kembali produk emas bekas dari pelanggan (baik yang disertai dokumen/surat pembelian lama, maupun yang rusak tanpa dokumen pendukung).
*   **Formula Penilaian Sistem (Auto-Valuation):**
    Nilai penawaran beli otomatis dihitung secara asinkron dengan rumus baku:
    $$\text{Harga Beli} = \left( \text{Berat Aktual (g)} \times \text{Kadar Kripto} \times \text{Harga Acuan Antam} \right) \times \left(1 - \frac{\text{Margin Ritel \%}}{100}\right)$$
    *Keterangan Tambahan:*
    - **Kadar Emas:** Nilai desimal standar (`0.375` untuk 9K, `0.585` untuk 14K, `0.750` untuk 18K, `0.916` untuk 22K, `0.999` untuk Antam murni).
    - **Margin Ritel:** Berada dalam konfigurasi ketat berkisar antara 5% hingga 12% sesuai kebijakan fluktuasi harian Owner.
    - **Pembulatan:** Seluruh kalkulasi harga beli dibulatkan ke bawah ke nilai rupiah terdekat menggunakan utilitas `MathUtils.roundInt()` untuk melindung likuiditas kas.
*   **Aturan Bisnis (SOP Ketat Emas):**
    1.  **Harga Acuan Usang:** Jika harga emas harian tidak diperbarui lebih dari **2 jam**, sistem memicu kunci perlindungan. Transaksi hanya dapat dilanjutkan dengan **Otorisasi Manajer** (Verifikasi PIN Gate di tempat).
    2.  **Sumbangan Kas Pembayaran:** Pembayaran transaksi buyback **MUTLAK** dikeluarkan dari sumber anggaran yang diberi label **Kas Emas (`gold_cash`)**, bukan laci kasir ritel biasa harian. Ini untuk memisahkan neraca likuidasi emas dan omset kasir ritel imitasi.
    3.  **Pelarangan Ritel Emas:** Semua perhiasan emas yang dibeli melalui buyback berstatus *Treasury Aset*. Barang ini **DIREKAM** untuk dilebur/dijual dalam skala B2B kepada kolektor/pelebur skala besar hulu (dicatat di `gold_liquidations`), **DILARANG KERAS** dijual ulang secara eceran ritel kepada pelanggan umum di kasir POS konvensional.

### 3.4 Penutupan Shift & Rekonsiliasi Kas (Shift Handover)
*   **Verifikasi Kasir Akhir Shift:**
    - Di akhir jam kerja, kasir wajib menghitung seluruh fisik uang tunai di laci kasir ritel dan memasukkan angka total fisik ke dalam sistem.
    - Sistem akan menghitung neraca teoritis kasir (*Expected Cash*) berdasarkan kalkulasi:
      $$\text{Expected Cash} = \text{Start Cash} + \text{Retail Cash In} - \text{Retail Cash Out}$$
*   **Kebijakan Batas Selisih (Discrepancy Threshold):**
    - Batas toleransi selisih uang kas fisik dengan hitungan sistem ditetapkan sebesar **Rp 50.000**.
    - Jika selisih kas fisik nyata berada di atas threshold (misal: kas berkurang Rp 70.000 dari hitungan sistem), kasir **TIDAK AKAN** diizinkan menutup shift secara mandiri.
    - Transaksi pencatatan selisih besar ini memerlukan verifikasi **Admin / Manager Master PIN** di tempat.
    - Kejadian selisih keuangan ini akan di-log sebagai anomali bernilai tinggi pada laporan audit visual Owner dashboard.

### 3.5 Penutupan Buku Harian Kriptografis (Daily Closure)
*   **SLA Persyaratan Utama:**
    Fungsi penutupan harian (`createDailyClosure`) memiliki guard yang keras:
    1.  Mesin harus **online** (`navigator.onLine === true`) untuk mencegah diskrepansi nomor rantai data (*split-brain*).
    2.  Tidak boleh ada antrean sinkronisasi yang tertunda (`pendingSyncCount === 0`) untuk menjamin data IndexedDB lokal identik dengan Firestore Cloud.
*   **Hashing Rantai Data (Audit Chain Integrity):**
    - Setiap penutupan harian menghasilkan objek `FinancialClosure` yang melingkupi ringkasan total penjualan, margin, mutasi kas masuk, dan kas keluar.
    - Objek summary dikompres ke string JSON dan ditambahkan nilai hash penutupan hari sebelumnya (`previousHash`).
    - String gabungan ini diproses menggunakan algoritma asinkron **SHA-256** untuk memproduksi tanda tangan daktiloskopik data mutlak (`hash`).
    - Hari pertama sistem menggunakan konstanta genesis: `GENESIS_BLOCK_0000000000000000`.
    - Skema ini mencegah kecurangan masa lampau di mana personil internal memodifikasi total penjualan minggu lalu di database secara manual; modifikasi di satu rekaman secara otomatis memutuskan seluruh sambungan hash berikutnya, yang akan dilaporkan saat pengujian rantai harian dijalankan (`verifyChain`).

---

## 4. TECHNICAL DEEP-DIVE (FOR DEVELOPER & AI AGENTS)

### 4.1 Skema Spesifik Database Lokal (Dexie IndexedDB)
Berikut adalah konfigurasi parameter index tabel Dexie dalam `PSA_POS_DB` (diambil langsung dari `src/shared/api/db.ts`):

```ts
this.version(1).stores({
  stock: 'id, name, category, barcode, quantity, branchId',
  transactions: 'id, date, status, sessionId, customerId, branchId',
  repair_services: 'id, date, customerName, status, paymentMethod, branchId',
  audit_logs: 'id, timestamp, action, user, userId, branchId, entityId',
  shifts: 'id, startTime, status, user, branchId',
  sync_events: '++id, entity_type, status, timestamp, idempotency_key',
  users: 'id, name, role, status, branchId',
  customers: 'id, name, phoneNumber, loyaltyPoints, version, branchId',
  notifications: 'id, recipient, timestamp, status',
  gold_liquidations: 'id, date, status, paymentMethod, branchId',
  gold_price: 'id',
  daily_gold_price: 'date, branchId',
  gold_buyback: 'id, date, customerName, paymentMethod, status, branchId',
  stock_history: 'id, stockId, timestamp, action',
  gold_asset_history: 'id, timestamp, action',
  suspended_carts: 'id, timestamp, user, branchId',
  handovers: 'id, timestamp, category, branchId',
  petty_cash: 'id, date, category',
  appointments: 'id, date, status',
  custom_orders: 'id, date, status',
  internal_notes: 'id, date, category',
  keys_meta: 'id, keyId',
  keyval: 'key',
  sync_dlq: '++id, entity_type, status, timestamp, idempotency_key',
  shift_totals: 'id, startTime',
  analytics_cache: 'id, expiresAt',
  fraud_anomalies: 'id, txId, cashierId, status, severity, timestamp',
  telemetry_events: 'id, timestamp, eventType, userId',
  ai_cache: 'queryHash, expiresAt',
  ai_access_logs: 'id, timestamp, queryHash',
  ai_feedback_tickets: 'id, timestamp, status, sync_status, category',
  financial_closures: 'id, date, branchId',
  store_profile: 'id, isSetupComplete'
});

// Version 2 Upgrade: Menambahkan sistem deteksi konflik multi-perangkat via CRDT
this.version(2).stores({
  stock: 'id, name, category, barcode, quantity, branchId, version'
});
```

### 4.2 Struktur Tipe Entitas Utama
Tipe data kunci didefinisikan secara eksplisit untuk mencegah inefisiensi memori (lihat `/src/types.ts` dan domain models untuk sinkronisasi):

*   **`StockItem`:**
    ```typescript
    export interface StockItem {
      id: string;
      name: string;
      category: StockCategory;
      price: number;       // Ritel Sell Price
      cost: number;        // Nilai HPP (Cost of Goods Sold)
      quantity: number;    // Jumlah Fisik Inventori
      barcode: string;     // Unique SKU identifier
      weight?: number;     // Gramasi (untuk perhiasan perak/emas penunjang)
      version?: number;    // Versi mutasi (CRDT conflict checker)
      isDeleted?: boolean; // Flag Soft Delete
    }
    ```
*   **`AuditLog`:**
    ```typescript
    export interface AuditLog {
      id: string;
      timestamp: number;
      action: string;      // Contoh: 'CHECKOUT', 'VOID_TRANSACTION', 'MUTATE_STOK'
      user: string;        // Nama pelaksana
      userId?: string;     // ID Relasional user
      details: string;     // Penjelasan kejadian kontekstual
      hash: string;        // SHA-256 hash log ini = hash(log ini + previousHash)
      previousHash: string;// Linker log audit sebelumnya
    }
    ```

### 4.3 Spesifikasi BFF Proxy API Backend (`/api/*`)
Backend server berjalan asinkron di `/api/*` (dikelola oleh vercel/serverless yang didefinisikan dalam `/api/index.ts`):

1.  **`POST /api/ask-gemini`**
    -   **Deskripsi:** Gateway asinkron untuk kueri bahasa alami (NLQ) data analisis bisnis oleh Owner.
    -   **Kepatuhan Privasi (PII Masking):** Sebelum payload data keuangan atau stok dikirim ke API Gemini, backend melakukan sensor seluruh string data teks sensitif kasir / profil pelanggan menggunakan ekspresi reguler regex terpusat:
        -   Email disamarkan menjadi `<<PII_REMOVED>>`.
        -   Nomor HP (pola 08 atau +62) disamarkan menjadi `<<PII_REMOVED>>`.
        -   Kredit Card atau Nomor NIK (angka 16 digit) dipotong penuh.
2.  **`POST /api/hash-pin`**
    -   **Deskripsi:** Melakukan proses hash satu arah asinkron master PIN menggunakan PBKDF2 asinkron.
    -   **Parameter Keamanan:**
        -   Menggunakan dynamic Salt dan dynamic Pepper yang dibaca dari variabel rahasia server (`CRYPTO_PEPPER`).
        -   **CPU Hard-Cap Buffer:** Iterasi komputasi PBKDF2 secara tegas dibatasi di angka maksimal **650.000 iterasi** untuk mencegah serangan kelelahan prosesor (Denial of Service CPU exhaustion).
3.  **`POST /api/telegram-alert`**
    -   **Deskripsi:** Mengirimkan pesan notifikasi krisis atau anomali fatal keuangan toko kasir ke admin sistem atau grup Telegram Owner.
    -   **Kondisi Pengiriman:** Dipicu otomatis jika terjadi *error* kritis sinkronisasi DB, peretasan hak akses, atau selisih uang kas laci kasir yang bernilai tidak lazim (> threshold).

### 4.4 Struktur Direktori Project (Feature-Sliced Design Map)
Peta organisasi komponen kode sumber diklasifikasikan sebagai berikut:

```
├── /api                   # Entry point BFF (Backend for Frontend Serverless)
├── /src
│   ├── /app               # Konfig routing utama & Main Layout shell
│   ├── /domain            # Entities, pure domain rules, & repository interfaces
│   ├── /application       # Service layer logic, inter-modul controllers, & Use Cases
│   ├── /infrastructure    # Concrete implementations (Dexie, Firebase sync, drivers)
│   ├── /features          # Modul fungsional dipisah per divisi bisnis (FSD)
│   │   ├── /auth          # Login, morning checklist perangkat, PIN Gate
│   │   ├── /pos           # Keranjang ritel, catalog widget, checkout, petty cash
│   │   ├── /gold          # Formulir buyback forensik, Treasury management
│   │   ├── /inventory     # SKU generator, stock history, bulk import stock list
│   │   ├── /shift         # Prosedur shift open/close, handover, selisih rekonsiliasi
│   │   └── /reports       # Dasbor visual Recharts, financial ledger status
│   ├── /shared            # Reusable UI core components, custom stores, utility math
│   └── /workers           # Web workers latar belakang (analytics, sync, health health)
└── /tests                 # Suite pengujian E2E, integrasi bisnis, & stress-test DB
```

---

## 5. OPERATIONAL MANUAL (PANDUAN OPERASIONAL)

### 5.1 Langkah Instalasi & Inisialisasi Developer (Setup Guide)
1.  **Pastikan Kebutuhan Terpenuhi:** Pasang Node.js LTS (versi 18.x atau 20.x disarankan).
2.  **Kloning Kode Sumber:**
    ```bash
    git clone https://github.com/devPSA-Business/PSA-Business-Suite.git
    cd PSA-Business-Suite
    ```
3.  **Pasang Library Dependencies:**
    ```bash
    npm install
    ```
4.  **Konfigurasi Variabel Lingkungan:**
    Salin templat konfigurasi hulu:
    ```bash
    cp .env.example .env.local
    ```
    Buka `.env.local` dan lengkapi variabel rahasia:
    *   `GEMINI_API_KEY`: API token Google AI Studio untuk kecerdasan sistem dasbor.
    *   `CRYPTO_PEPPER`: String acak aman untuk membumbui PBKDF2 hash.
    *   `TELEGRAM_BOT_TOKEN` & `TELEGRAM_CHAT_ID`: Pengaktif modul peringatan real-time Telegram.
5.  **Jalankan Mesin Developer Lokal:**
    ```bash
    npm run dev
    ```
    Aplikasi akan mengudara secara luring lokal di `http://localhost:3000`.

### 5.2 Panduan Deploy & Migrasi Produksi
*   **Kompilasi Modul Siap Rilis:**
    ```bash
    npm run build
    ```
    Proses ini merangkum seluruh aset, membuang kode logger konsol tak terpakai (`vite-plugin-remove-console`), melampirkan modul PWA manifest, dan melontarkan hasil ke folder `/dist`.
*   **Penyebaran Firebase Hosting:**
    ```bash
    npm run deploy:prod
    ```

### 5.3 Cara Pemasangan di Tablet Kasir Toko Fisik (PWA Installation)
Aplikasi sangat dioptimalkan untuk performa tablet Android/iOS kasir hand-hold:
1.  Buka browser **Google Chrome** di tablet kasir fisik.
2.  Arahkan ke alamat URL rilis produksi yang diberikan administrator Owner.
3.  Biarkan aplikasi merender halaman awal penuh. Browser akan memunculkan banner mengembang di bilah atas/bawah bertuliskan **"Install App"** atau klik ikon menu tiga titik Chrome dan pilih **"Add to Home screen"**.
4.  Ikon aplikasi **PSA Business Suite** akan terpasang di beranda utama tablet.
5.  Aplikasi kini dapat diluncurkan tanpa bingkai browser standar, mengunci pemanfaatan layar penuh, dan aset UI utama terinstal permanen di memori lokal (*pre-cached offline capacity*).

---

## 6. SECURITY HARDENING, TROUBLESHOOTING, & MAINTENANCE

### 6.1 PolicyPrompt P0 & Kepatuhan Keamanan
Seluruh pengembang dan AI Agents yang ditugasi memelihara PSA Business Suite **WAJIB** tunduk tanpa perkecualian pada parameter keamanan berikut:
1.  **Zero Personal Identifiable Information (PII) Exposure:**
    Sistem wajib melarang pengiriman data mentah identitas pribadi konsumen (nama lengkap, nomor telepon, alamat, dsb) ke layanan LLM eksternal atau log debugging umum. Pelanggaran aturan ini dideteksi otomatis oleh skrip audit pra-commit.
2.  **No Core Secrets in Frontend Client Code:**
    Tidak boleh ada variable berkepala `VITE_` yang menampung API Key rahasia pihak ketiga yang berisiko disadap via browser devtools penjelajah. Semua operasi sensitif wajib dialihkan ke Backend BFF (`server.ts` / `/api/*`).
3.  **Auto Lock Screen On Hidden Tab:**
    Modul `PinGate.tsx` mengaitkan sistem listening event pada status visibilitas halaman (`visibilitychange`). Begitu layar tablet kasir padam, atau tab aplikasi dialihkan, status keamanan langsung mengunci diri secara otomatis (`lock()`), menghalangi infiltrasi fisik rekan kerja tidak bertanggung jawab di toko fisik.

### 6.2 Skenario Penanganan Kegagalan (Troubleshooting Guide)
*   **Kasus 1: Selisih Kasir di Atas Batas threshold sewaktu Serah Terima Shift.**
    -   *Gejala:* Layar menampilkan peringatan "Otorisasi Diperlukan" dan tombol "Selesai" terkunci.
    -   *Langkah:* Panggil Manajer atau Owner ke tablet kasir. Manajer wajib memeriksa keabsahan fisik uang tunai dalam laci kasir manual. Jika manajer menyetujui penutupan dengan selisih tersebut, ia harus memasukkan **6-Digit Master PIN** pada popup verifikasi. Sistem akan menyelesaikan penyimpanan shift, merilis database, dan mencatat mutasi rugi/selisih di log audit dengan verifikator manajer.
*   **Kasus 2: Koneksi Sinkronisasi data macet (Error Sync Connection).**
    -   *Gejala:* Indikator reaktif di pojok dasbor menampilkan "X Transaksi Pending" dalam waktu lama meskipun tabel kasir sudah mendapatkan akses internet wifi normal.
    -   *Langkah Solusi:*
        1. Buka menu **"Dashboard System Status"** level Manager.
        2. Klik tombol **"Force Re-sync"** untuk memicu paksa interval background worker pendorong events.
        3. Jika kegagalan disebabkan konflik benturan versi stok data, kunjungi halaman **"Conflict Resolver Page"** untuk menyelesaikan benturan data secara manual demi memilih versi data dominan (Server vs Lokal).

---

## 7. AI AGENTS DESIGN INSTRUCTIONS (KNOWLEDGE BASE PROMPT)

> *Bagian khusus ini didedikasikan untuk AI Agents (Gemini, Claude, dsb) yang membaca dokumentasi ini sebagai basis pemahaman sebelum memodifikasi atau memperluas kode.*

### 7.1 Aturan Kompilasi & Penulisan Kode yang Tidak Boleh Dilanggar
Saat Anda (AI Agent) ditugaskan mengedit file program di project ini, patuhi secara kaku protokol berikut:

1.  **Prinsip Desain Feature-Sliced Design (FSD):**
    -   Jangan pernah menuliskan logika bisnis, querying database IndexedDB langsung, atau otentikasi pin kasir di dalam file halaman (`/src/pages/*`) atau komponen UI umum (`/src/shared/*`).
    -   Logika manipulasi data wajib dikurung di dalam layanan Use Cases (`/src/features/[feature]/usecases/`) atau modul Application Services.
2.  **Akurasi Matematika Mutlak (Aritmatika Keuangan):**
    -   **DILARANG KERAS** menggunakan operator matematika standar javascript (`+`, `-`, `*`, `/`) jika berurusan dengan kuantitas stok produk, nilai rupiah, gramasi emas, margin loyalitas, dan perhitungan diskon.
    -   **WAJIB** membungkus kalkulasi menggunakan helper kelas Decimal dalam file `/src/shared/utils/decimalUtils.ts` atau memanggil pustaka `Decimal.js` langsung secara modular untuk menghindari degradasi ketelitian angka desimal.
3.  **Pillar of Truth - Dexie SSoT:**
    -   IndexedDB (`Dexie`) adalah sumber data kebenaran tunggal tingkat pertama (SSoT). Database awan Firestore hanya berfungsi sebagai sistem replikasi pelaporan jarak jauh.
    -   Jangan pernah membaca status server Firebase langsung untuk memandu keputusan rendering visual kasir POS; seluruh query reaktif mutlak dibaca dari adapter lokal Dexie agar performa luring tetap sempurna.
4.  **Enkapsulasi Imports Modular:**
    -   Semua file import di bagian atas wajib didefinisikan secara eksplisit untuk tipe-tipe modular khusus. Hindari teknik destruktif impor global jika merusak performa *tree-shaking* sistem bundler Vite.

### 7.2 Daftar Glosarium Istilah (Glossary)
*   **BFF (Backend for Frontend):** Server perantara aman yang dipasang di `/api/` untuk memfasilitasi transaksi kriptografi rahasia dan masking PII sebelum diteruskan ke internet publik.
*   **Buyback Forensik:** Proses pembelian emas kembali dari pelanggan tanpa surat kepemilikan formal secara aman dengan audit ketat, timbangan digital terintegrasi, dan perlindungan fluktuasi harga emas harian.
*   **Kas Emas (Gold Cash):** Dompet keuangan terpisah khusus urusan emas, menghalangi percampuran uang omset dengan perhiasan imitasi ritel harian.
*   **Morning Readiness:** SOP pemeriksaan asinkron hardware penunjang operasional toko ritel perhiasan setiap pagi sebelum pembukaan transaksi diizinkan.
*   **Pin Gate:** Layar pengunci reaktif asinkron di frontend yang melindung area laporan, otorisasi transaksi selisih kas, atau pemulihan data berbasis Master PIN 6-angka.
*   **Unit of Work:** Pola desain transaksional atomik ACID lokal untuk menjamin sekumpulan aksi penulisan databaseIndexedDB berhasil secara utuh, atau gagal bersamaan secara bersih (*rollback-ready*).

---

## 8. INTEGRITY CHECKLIST & DISCOVERY QUESTIONS (PANDUAN FEEDBACK)

Kepada Owner / Tim IT, demi menyempurnakan keabsahan dokumentasi teknis ini ke level tertinggi, berikut beberapa parameter sistem pelapor rilis yang dapat Anda jawab atau konfirmasikan jika sistem mengalami pemutakhiran berikutnya:

1.  **Dimensi Spesifik Terminal Timbangan (Gold Scale):**
    `[NEED MORE INFO: Apakah protokol koneksi Serial USB Timbangan Emas menggunakan standar industri ESC/POS, driver khusus vendor CH340, atau format ASCII baku? Tolong berikan representasi tipe output string data timbangan agar adapter ScaleService kita dapat diaudit ketat.]`
2.  **Konfigurasi Akun Penyimpanan Cloud Produksi (Firebase Target):**
    `[NEED MORE INFO: Apakah security rules Firestore di console produksi Anda saat ini telah divalidasi menggunakan bundel test unit `@firebase/rules-unit-testing` untuk memastikan penulisan log audit di cloud bersifat immutable (Writ-Once, No-Delete, No-Update)?]`
3.  **Telegram Chat ID & Disaster Recovery Alert:**
    `[NEED MORE INFO: Silakan pastikan set parameter `TELEGRAM_CHAT_ID` menggunakan saluran privat khusus pimpinan atau channel krisis tertutup yang tidak dapat disusupi personil toko umum guna menjaga rahasia anomali keuangan harian.]`

---
*Dokumen Manual Book ini berstatus resmi dan berderajat Otoritatif untuk PSA Business Suite v1.5.0.*
