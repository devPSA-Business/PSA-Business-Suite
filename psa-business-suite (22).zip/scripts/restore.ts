import { execSync } from 'child_process';
try {
  execSync('git checkout src/infrastructure/queries/LiveQueriesImpl.ts src/infrastructure/services/sync/SyncConflictHandler.ts src/features/workspace/components/CommunicationBoard.tsx');
  console.log('Restored');
} catch(e) {
  console.error(e);
}
