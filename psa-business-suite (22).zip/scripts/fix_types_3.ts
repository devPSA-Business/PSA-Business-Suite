import * as fs from 'fs';

function removeLineWithText(path: string, text: string) {
  try {
    let c = fs.readFileSync(path, 'utf8');
    let lines = c.split('\n');
    lines = lines.filter(l => !l.includes(text));
    fs.writeFileSync(path, lines.join('\n'));
  } catch(e) {}
}

const files = [
  'src/features/gold/ui/GoldBuybackSalesPage.tsx',
  'src/features/inventory/components/InventoryItemDetailModal.tsx',
  'src/features/inventory/ui/BarcodePrintPage.tsx',
];

files.forEach(f => removeLineWithText(f, 'P0: Type Migration'));
