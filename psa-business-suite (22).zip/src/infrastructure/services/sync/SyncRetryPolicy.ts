export class RetryPolicy {
  /**
   * Exponential backoff dengan jitter untuk mencegah thundering herd.
   * Formula: baseDelay × (2 ^ attemptNumber) + random jitter
   */
  static getBackoffMs(attemptNumber: number): number {
    const baseDelay = 5000; // 5 detik
    const maxDelay = 15 * 60 * 1000; // 15 menit cap
    const exponent = Math.min(attemptNumber, 5); // 2^5 = 32x multiplier
    
    const delay = baseDelay * Math.pow(2, exponent);
    const jitter = Math.random() * Math.min(delay, 30000); // 0-30s jitter
    
    return Math.min(delay + jitter, maxDelay);
  }

  /**
   * Mengklasifikasikan apakah error bersifat sementara (transient) atau permanen.
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  static isTransientError(error: any): boolean {
    if (!error) return false;
    
    const code = String(error?.code || error?.status || '');
    const msg = String(error?.message || error || '').toLowerCase();
    
    // Transient codes: timeout (deadline-exceeded), unavailable, too-many-requests (resource-exhausted), etc.
    const transientCodes = ['unavailable', 'deadline-exceeded', 'resource-exhausted', '429', '503', '504'];
    if (transientCodes.includes(code)) return true;
    
    // Transient messages
    if (
      msg.includes('network') || 
      msg.includes('timeout') || 
      msg.includes('try again') || 
      msg.includes('unavailable') ||
      msg.includes('offline')
    ) {
      return true;
    }
    
    return false;
  }
}
