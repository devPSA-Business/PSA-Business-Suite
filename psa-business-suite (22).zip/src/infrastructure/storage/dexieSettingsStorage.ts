import { StateStorage } from 'zustand/middleware';
import { db } from '../../shared/api/db';

export const dexieSettingsStorage: StateStorage = {
  getItem: async (name: string): Promise<string | null> => {
    try {
      const record = await db.keyval.get(name);
      return (record?.value as string) || null;
    } catch {
      return null;
    }
  },
  setItem: async (name: string, value: string): Promise<void> => {
    try {
      await db.keyval.put({ key: name, value });
    } catch (error) {
      console.error("Failed to setItem in dexieSettingsStorage:", error);
    }
  },
  removeItem: async (name: string): Promise<void> => {
    try {
      await db.keyval.delete(name);
    } catch (error) {
      console.error("Failed to removeItem in dexieSettingsStorage:", error);
    }
  },
};
