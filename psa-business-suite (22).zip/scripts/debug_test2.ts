import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncServiceImpl.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace("await syncService.processSyncQueue();", 
  "const spy = vi.spyOn(console, 'log');\n      await syncService.processSyncQueue();\n      throw new Error('EVENTS: ' + JSON.stringify(await db.sync_events.where('status').equals('PENDING').filter(() => true).toArray()));");

fs.writeFileSync(filePath, content, 'utf-8');
