# Gemini API Proxy

A Cloudflare Worker to proxy requests to the Google Gemini API, keeping the API key hidden from the frontend application.

## Setup Instructions

1. Install dependencies:
   \`\`\`bash
   cd workers/gemini-proxy
   npm install
   \`\`\`

2. Authenticate with Cloudflare:
   \`\`\`bash
   npx wrangler login
   \`\`\`

3. Set your internal Gemini API key as a secret:
   \`\`\`bash
   npx wrangler secret put GEMINI_API_KEY
   \`\`\`
   (Paste your Gemini API key when prompted)

4. Configure your origins in \`wrangler.toml\` (Optional but recommended):
   Set \`ALLOWED_ORIGIN\` to your Firebase Hosting URL (e.g., \`https://psa-business-suite.web.app\`) to restrict access.

5. Deploy the proxy:
   \`\`\`bash
   npx wrangler deploy
   \`\`\`

6. In your PSA Business Suite project, set your proxy URL in \`VITE_GEMINI_PROXY_URL\` and use it similarly to the Gemini SDK.
