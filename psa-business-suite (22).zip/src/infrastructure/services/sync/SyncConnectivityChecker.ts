import { isConfigValid } from '../../../shared/api/firebase';

export class SyncConnectivityChecker {
  async isFirestoreReachable(): Promise<boolean> {
    if (!navigator.onLine || !isConfigValid) {
      return false;
    }
    // Simple offline/online checks. Since navigator.onLine is checked, we can safely return true
    return true;
  }
}
