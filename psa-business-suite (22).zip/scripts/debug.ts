import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'src/infrastructure/services/sync/SyncUploaderService.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// We can just look at the console output without modifying if we just run vitest
