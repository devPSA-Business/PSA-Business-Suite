import { ErrorInfo } from 'react';
import { db } from '../api/db';
import { logger } from '../../lib/logger';

// Regex fallback if needed, but we rely on systematic interception now
const PII_REGEX = [
  /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g, // email
  /\b\d{16}\b/g, // NIK
  /\+?\d{8,15}/g // Phone
];

export const logError = async (error: Error, errorInfo?: ErrorInfo, user: string = 'unknown') => {
  const errorPayload = {
    user,
    message: (error instanceof Error ? error.message : String(error)),
    componentStack: errorInfo?.componentStack,
    stack: error.stack,
    timestamp: Date.now()
  };

  // Tetap log ke console menggunakan logger tersanitasi
  logger.error("APP_ERROR_LOG", errorPayload);

  // Simpan ke IndexedDB untuk di sync ke Firestore (Visibility error di production)
  try {
    // Sanitasi payload sebelum simpan ke DB secara sistematis 
    // Menerapkan regex replace pada string value level top jika ada yang bocor 
    let sanitizedMessage = errorPayload.message;
    if (sanitizedMessage) {
        PII_REGEX.forEach(regex => {
            sanitizedMessage = sanitizedMessage.replace(regex, '<<PII_REMOVED>>');
        });
    }

    const sanitizedPayload = {
        ...errorPayload,
        message: sanitizedMessage
    };
    
    await db.sync_events.add({
      entity_type: 'error_log',
      action: 'INSERT',
      payload: sanitizedPayload,
      status: 'PENDING',
      timestamp: Date.now()
    });
  } catch (e) {
    logger.error("Gagal mencatat error ke DB", e);
  }
};
