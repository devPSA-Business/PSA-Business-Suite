import * as fs from 'fs';
import * as path from 'path';

function removeLog(filePath: string, search: RegExp | string, replace: string) {
  let content = fs.readFileSync(filePath, 'utf-8');
  content = content.replace(search, replace);
  fs.writeFileSync(filePath, content, 'utf-8');
}

// 1. SyncUploaderService.ts
removeLog(
  path.join(process.cwd(), 'src/infrastructure/services/sync/SyncUploaderService.ts'),
  "async upload(events: SyncEvent[]): Promise<void> {\nconsole.log('UPLOAD EVENTS LENGTH: ', events.length);\n    const chunks: SyncEvent[][] = [];",
  "async upload(events: SyncEvent[]): Promise<void> {\n    const chunks: SyncEvent[][] = [];"
);

// 2. SyncQueueManager.ts
removeLog(
  path.join(process.cwd(), 'src/infrastructure/services/sync/SyncQueueManager.ts'),
  "async markSynced(eventIds: number[]): Promise<void> {\nconsole.log('MARK SYNCED CALLED WITH: ', eventIds);",
  "async markSynced(eventIds: number[]): Promise<void> {"
);

// 3. SyncServiceImpl.spec.ts
removeLog(
  path.join(process.cwd(), 'tests/unit/sync/SyncServiceImpl.spec.ts'),
  "transaction: vi.fn(async (...args) => {\nconsole.log('TRANSACTION CALLED WITH:', args.length, typeof args[args.length - 1]);\n      const cb = args[args.length - 1];",
  "transaction: vi.fn(async (...args) => {\n      const cb = args[args.length - 1];"
);

console.log('Cleaned logs');
