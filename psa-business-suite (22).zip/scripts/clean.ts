import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncServiceImpl.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// remove second inject
content = content.replace(/const spy = vi\.spyOn\(console, 'log'\);\n\s*await syncService\.processSyncQueue\(\);\n\s*throw new Error\([^)]*\);\n\s*spy\.mockRestore\(\);\n\s*spy\.mockRestore\(\);/g, 'await syncService.processSyncQueue();');
// remove first inject
content = content.replace(/const spy = vi\.spyOn\(console, 'error'\);\n\s*await syncService\.processSyncQueue\(\);\n\s*if\(spy\.mock\.calls\.length > 0\) throw new Error\([^)]*\);\n\s*spy\.mockRestore\(\);/g, 'await syncService.processSyncQueue();');
// aggressive match
content = content.replace(/const spy = vi\.spyOn\(console, 'log'\);[\s\S]*?spy\.mockRestore\(\);/g, 'await syncService.processSyncQueue();');
content = content.replace(/const spy = vi\.spyOn\(console, 'error'\);[\s\S]*?spy\.mockRestore\(\);/g, 'await syncService.processSyncQueue();');

fs.writeFileSync(filePath, content, 'utf-8');
console.log('Fixed file.');
