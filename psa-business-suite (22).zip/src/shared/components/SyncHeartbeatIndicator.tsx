import React from 'react';
import { ShieldCheck, ShieldAlert, AlertTriangle, RefreshCw, Clock } from 'lucide-react';

export interface HealthReport {
  status: 'GREEN' | 'WARNING' | 'CRITICAL';
  timestamp: number;
  issues: Array<{
    id: string;
    message: string;
    severity: 'WARNING' | 'CRITICAL';
  }>;
}

interface SyncHeartbeatIndicatorProps {
  report: HealthReport | null;
  isLoading: boolean;
  onRefresh: () => void;
}

export function SyncHeartbeatIndicator({ report, isLoading, onRefresh }: SyncHeartbeatIndicatorProps) {
  const getStatusConfig = () => {
    if (!report) {
      return {
        icon: <ShieldCheck size={28} className="text-stone-400" />,
        title: 'Status Belum Diperiksa',
        desc: 'Silakan jalankan pemeriksaan sistem.',
        bgColor: 'bg-stone-50',
        borderColor: 'border-stone-100',
        textColor: 'text-stone-800'
      };
    }

    switch (report.status) {
      case 'GREEN':
        return {
          icon: <ShieldCheck size={28} className="text-green-500 animate-pulse" />,
          title: 'Sistem Sehat',
          desc: 'Seluruh engine sinkronisasi dan database lokal berjalan aman.',
          bgColor: 'bg-green-50',
          borderColor: 'border-green-100',
          textColor: 'text-green-800'
        };
      case 'WARNING':
        return {
          icon: <AlertTriangle size={28} className="text-amber-500" />,
          title: 'Perhatian Terdeteksi',
          desc: 'Terjadi delay sync minor atau keterbatasan koneksi cloud.',
          bgColor: 'bg-amber-50',
          borderColor: 'border-amber-100',
          textColor: 'text-amber-800'
        };
      case 'CRITICAL':
        return {
          icon: <ShieldAlert size={28} className="text-red-500 animate-bounce" />,
          title: 'Gangguan Kritis',
          desc: 'Beberapa sync event tertolak atau database mengalami stall.',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-100',
          textColor: 'text-red-800'
        };
    }
  };

  const config = getStatusConfig();

  return (
    <div className="w-80 p-5 bg-white rounded-2xl flex flex-col gap-4 select-none">
      <div className={`p-4 rounded-xl border ${config.borderColor} ${config.bgColor} flex items-start gap-3`}>
        <div className="shrink-0 mt-0.5">{config.icon}</div>
        <div>
          <h4 className={`font-bold ${config.textColor} text-sm`}>{config.title}</h4>
          <p className="text-xs text-stone-500 mt-1 leading-relaxed">{config.desc}</p>
        </div>
      </div>

      {report && report.issues.length > 0 && (
        <div className="flex flex-col gap-1.5 max-h-40 overflow-y-auto pr-1">
          <p className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">Temuan Masalah</p>
          {report.issues.map((issue) => (
            <div
              key={issue.id}
              className="p-2 bg-stone-50 rounded-lg border border-stone-200 text-xs text-stone-700 flex items-start gap-1.5"
            >
              <span className={`inline-block w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                issue.severity === 'CRITICAL' ? 'bg-red-500' : 'bg-amber-500'
              }`} />
              <span>{issue.message}</span>
            </div>
          ))}
        </div>
      )}

      <div className="border-t border-stone-100 pt-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-1 text-stone-400 text-[10px] font-medium">
          <Clock size={12} />
          <span>
            {report
              ? `Diupdate: ${new Date(report.timestamp).toLocaleTimeString('id-ID')}`
              : 'Belum ada data'}
          </span>
        </div>
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 disabled:bg-stone-200 text-white disabled:text-stone-400 text-xs font-bold rounded-lg transition-all active:scale-95 flex items-center justify-center gap-1.5 shadow-sm"
        >
          <RefreshCw size={12} className={isLoading ? 'animate-spin' : ''} />
          <span>Check</span>
        </button>
      </div>
    </div>
  );
}
