import * as Sentry from '@sentry/react';

export async function initSentry(): Promise<void> {
  const dsn = import.meta.env.VITE_SENTRY_DSN;
  if (!dsn) {
    console.log('[Sentry] DSN tidak dikonfigurasi, Sentry dinonaktifkan.');
    return;
  }

  try {
    Sentry.init({
      dsn,
      integrations: [
        Sentry.browserTracingIntegration(),
        Sentry.replayIntegration(),
      ],
      tracesSampleRate: 1.0,
      replaysSessionSampleRate: 0.1,
      replaysOnErrorSampleRate: 1.0,
    });
    console.log('[Sentry] Berhasil diinisialisasi.');
  } catch (err) {
    console.error('[Sentry] Gagal inisialisasi:', err);
  }
}
