import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncServiceImpl.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// Replace anyOf mock with equals/filter mock globally
content = content.replace(/anyOf: vi\.fn\(\)\.mockReturnValue\(\{ toArray: vi\.fn\(\)\.mockResolvedValue\(events\) \}\)/g, 
  "equals: vi.fn().mockReturnValue({ filter: vi.fn().mockReturnValue({ toArray: vi.fn().mockResolvedValue(events) }) })");

fs.writeFileSync(filePath, content, 'utf-8');
console.log('Successfully replaced mocks.');
