import { db, SyncEvent } from '../../../shared/api/db';
import { guardSyncEnqueue } from '../../../shared/utils/syncGuard';
import { useAuthStore } from '../../../shared/store/authStore';

export class SyncQueueManager {
  /** Enqueue event to Dexie localized sync queue */
  async enqueue(event: Omit<SyncEvent, 'id' | 'status' | 'timestamp'>): Promise<number> {
    const branchId = useAuthStore.getState().user?.branchId || 'HQ';
    const payload = { ...event.payload };
    if (!payload.branchId) {
      payload.branchId = branchId;
    }

    const idempotency_key = event.idempotency_key || crypto.randomUUID();
    const docId = String(payload.client_txn_id || payload.id || crypto.randomUUID());
    
    const isSafe = await guardSyncEnqueue(event.entity_type, docId, idempotency_key);
    if (!isSafe) {
      return 0; // Ditolak karena duplikat
    }

    return await db.transaction('rw', db.sync_events, async () => {
      const existing = await db.sync_events
        .where('idempotency_key')
        .equals(idempotency_key)
        .first();
      if (existing && typeof existing.id === 'number') return existing.id;
      
      const syncEvent: SyncEvent = {
        ...event,
        payload,
        status: 'PENDING',
        timestamp: Date.now(),
        idempotency_key
      };
      const id = await db.sync_events.add(syncEvent);
      return typeof id === 'number' ? id : 0;
    });
  }

  /** Retrieve pending events that are executable (not stuck in retry backoff) */
  async getExecutableEvents(): Promise<SyncEvent[]> {
    return await db.sync_events
      .where('status')
      .equals('PENDING')
      .filter(e => !e.next_retry_time || e.next_retry_time <= Date.now())
      .toArray();
  }

  /** Mark event in conflict state with server payload cached */
  async markConflict(conflictEvents: { eventId: number; serverPayload: unknown }[]): Promise<void> {
    await db.transaction('rw', db.sync_events, async () => {
      for (const { eventId, serverPayload } of conflictEvents) {
        await db.sync_events.update(eventId, {
          status: 'CONFLICT',
          server_payload: serverPayload as Record<string, unknown>
        });
      }
    });
  }

  /** Mark event as successfully synced (deleted from localized queue to preserve storage) */
  async markSynced(eventIds: number[]): Promise<void> {
    await db.transaction('rw', db.sync_events, async () => {
      for (const id of eventIds) {
        await db.sync_events.delete(id);
      }
    });
  }

  /** Mark event failed and setup exponential backoff retry. Falls back to DLQ on max retries */
  async markFailed(eventId: number, errorMessage: string, currentEvent?: SyncEvent): Promise<void> {
    const retryCount = (currentEvent?.retry_count || 0) + 1;
    if (retryCount >= 5) {
      // Move to Dead Letter Queue (DLQ)
      await db.transaction('rw', db.sync_events, db.sync_dlq, async () => {
        const event = await db.sync_events.get(eventId);
        if (event) {
          const dlqEvent: SyncEvent = {
            ...event,
            status: 'FAILED',
            error_message: `[DLQ:max-retries] ${errorMessage}`
          };
          if (dlqEvent.payload && typeof dlqEvent.payload.photoBeforeBase64 === 'string') {
             dlqEvent.payload.photoBeforeBase64 = '[TRIMMED_FOR_DLQ]';
          }
          await db.sync_dlq.add(dlqEvent);
          await db.sync_events.delete(eventId);
        }
      });
    } else {
      const nextRetryTime = Date.now() + Math.pow(2, retryCount) * 1000; // Exponential Backoff
      await db.sync_events.update(eventId, {
        status: 'PENDING',
        retry_count: retryCount,
        next_retry_time: nextRetryTime,
        error_message: errorMessage
      });
    }
  }

  /** Heals stuck sync queue records back into pending after a timeout */
  async heal() {
    const stuckEvents = await db.sync_events
      .where('status').equals('PENDING')
      .and(e => Date.now() - e.timestamp > 300000) // Stuck for > 5 min
      .toArray();
      
    for (const event of stuckEvents) {
      const currentHeals = event.retry_count || 0;
      if (currentHeals >= 5) {
          const eventToDlq = { ...event, status: 'FAILED' as const, error_message: 'Max healing attempts reached' } as SyncEvent;
          if (eventToDlq.payload && typeof eventToDlq.payload.photoBeforeBase64 === 'string') {
             eventToDlq.payload.photoBeforeBase64 = '[TRIMMED_FOR_DLQ]';
          }
          await db.transaction('rw', db.sync_events, db.sync_dlq, async () => {
             await db.sync_dlq.add(eventToDlq);
             await db.sync_events.delete(event.id!);
          });
      } else {
          await db.sync_events.update(event.id!, { status: 'PENDING', timestamp: Date.now(), retry_count: currentHeals + 1 });
      }
    }
  }
}
