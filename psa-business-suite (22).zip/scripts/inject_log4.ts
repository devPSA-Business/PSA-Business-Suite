import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncServiceImpl.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace(
  /transaction: vi\.fn\(async \(\.\.\.args\) => \{/,
  "transaction: vi.fn(async (...args) => {\nconsole.log('TRANSACTION CALLED WITH:', args.length, typeof args[args.length - 1]);"
);

fs.writeFileSync(filePath, content, 'utf-8');
