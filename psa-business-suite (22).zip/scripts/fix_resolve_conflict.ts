import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/resolveConflict.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

if (!content.includes("vi.mock('../../../src/shared/api/firebase'")) {
  content = content.replace(
    /import \{ db \} from '\.\.\/\.\.\/\.\.\/src\/shared\/api\/db';/,
    `import { db } from '../../../src/shared/api/db';\n\nvi.mock('../../../src/shared/api/firebase', () => ({\n  firestoreDb: {},\n  isConfigValid: true,\n  safeFirestoreCall: vi.fn(async (cb) => await cb())\n}));\n`
  );
  fs.writeFileSync(filePath, content, 'utf-8');
  console.log('Fixed resolveConflict.spec.ts mock');
}
