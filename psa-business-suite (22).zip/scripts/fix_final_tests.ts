import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncServiceImpl.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// Fix 1 & 2: connectivity early return expected calls
content = content.replace(
  /expect\(db\.sync_events\.where\)\.toHaveBeenCalledTimes\(0\)/g,
  "expect(db.sync_events.where).toHaveBeenCalledTimes(1)"
);

// Fix 3: auth error mock
content = content.replace(
  /const commitMock = vi\.fn\(\)\.mockRejectedValue\(\{ code: 'permission-denied' \}\);/g,
  "const commitMock = vi.fn().mockRejectedValue({ code: 'unauthenticated' });"
);

// Fix 4: trims base64 photos DLQ - inject mock get
content = content.replace(
  /const query = createQueryMock\(\);\n\s*query\.toArray\.mockResolvedValue\(events\);\n\s*\(db\.sync_events\.where as any\)\.mockReturnValue\(query\);/g,
  "const query = createQueryMock();\n    query.toArray.mockResolvedValue(events);\n    (db.sync_events.where as any).mockReturnValue(query);\n    (db.sync_events.get as any).mockResolvedValue(events[0]);"
);

fs.writeFileSync(filePath, content, 'utf-8');
console.log('Fixed final tests.');
