import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncConflictHandler.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace(
  /handler\.classifyFirestoreError\('permission-denied'\)/g,
  "handler.classifyFirestoreError(Object.assign(new Error(''), { code: 'permission-denied' }))"
);
content = content.replace(
  /handler\.classifyFirestoreError\('failed-precondition'\)/g,
  "handler.classifyFirestoreError(Object.assign(new Error(''), { code: 'failed-precondition' }))"
);
content = content.replace(
  /handler\.classifyFirestoreError\('unavailable'\)/g,
  "handler.classifyFirestoreError(Object.assign(new Error(''), { code: 'unavailable' }))"
);
content = content.replace(
  /handler\.classifyFirestoreError\('deadline-exceeded'\)/g,
  "handler.classifyFirestoreError(Object.assign(new Error(''), { code: 'deadline-exceeded' }))"
);

fs.writeFileSync(filePath, content, 'utf-8');
console.log('Fixed handler spec.');
