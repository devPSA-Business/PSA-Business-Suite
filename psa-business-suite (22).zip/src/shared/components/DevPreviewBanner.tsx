import React from 'react';

export function DevPreviewBanner() {
  const isDev = import.meta.env.DEV;
  if (!isDev) return null;

  return (
    <div className="bg-amber-500 text-amber-950 px-4 py-1.5 text-center text-xs font-semibold select-none flex items-center justify-center gap-2">
      <span className="inline-block w-2 h-2 rounded-full bg-amber-950 animate-pulse"></span>
      Developer Preview Mode — Offline Database & Mock Sandbox Active
    </div>
  );
}
