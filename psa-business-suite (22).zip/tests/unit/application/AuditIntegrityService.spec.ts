import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { AuditIntegrityService } from '../../../src/application/services/AuditIntegrityService';
import { db } from '../../../src/shared/api/db';

vi.mock('../../../src/shared/api/db', () => ({
  db: {
    sync_events: {
      where: vi.fn().mockReturnThis(),
      equals: vi.fn().mockReturnThis(),
      count: vi.fn()
    },
    financial_closures: {
      get: vi.fn(),
      put: vi.fn(),
      where: vi.fn().mockReturnThis(),
      equals: vi.fn().mockReturnThis(),
      sortBy: vi.fn()
    },
    audit_logs: {
      orderBy: vi.fn().mockReturnThis(),
      reverse: vi.fn().mockReturnThis(),
      limit: vi.fn().mockReturnThis(),
      toArray: vi.fn()
    }
  }
}));

describe('AuditIntegrityService', () => {
  let service: AuditIntegrityService;
  let mockUow: any;
  let mockReportQuery: any;
  let onlineSpy: any;

  beforeEach(() => {
    mockUow = {
      execute: vi.fn(async (cb) => await cb()),
      registerSync: vi.fn(),
      registerAudit: vi.fn()
    };
    mockReportQuery = {
      getFinancialReport: vi.fn().mockResolvedValue({
        totalRevenue: 1000,
        grossProfit: 500,
        transactionCount: 2,
        cashFlow: { cashIn: 1000, cashOut: 0 }
      })
    };
    service = new AuditIntegrityService(mockUow, mockReportQuery);

    onlineSpy = vi.spyOn(navigator, 'onLine', 'get').mockReturnValue(true);

    // crypto subtle mock
    Object.defineProperty(global, 'crypto', {
      value: {
        subtle: {
          digest: vi.fn().mockResolvedValue(new ArrayBuffer(32)) // dummy hash
        }
      },
      writable: true
    });
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('createDailyClosure', () => {
    it('throws if offline', async () => {
      onlineSpy.mockReturnValue(false);
      await expect(service.createDailyClosure(new Date(), 'BR-1')).rejects.toThrow(/online/i);
    });

    it('throws if pendingSyncCount > 0', async () => {
      (db.sync_events.count as any).mockResolvedValue(1);
      await expect(service.createDailyClosure(new Date(), 'BR-1')).rejects.toThrow(/belum tersinkronisasi/i);
    });

    it('returns existing closure if already closed today', async () => {
      (db.sync_events.count as any).mockResolvedValue(0);
      const existing = { id: 'BR-1-2026-06-10' };
      (db.financial_closures.get as any).mockImplementation(async (id: string) => {
        if (id.includes('2026-06-10')) return existing;
        return undefined;
      });

      const result = await service.createDailyClosure(new Date('2026-06-10T15:00:00Z'), 'BR-1');
      expect(result).toBe(existing);
      expect(mockUow.registerSync).not.toHaveBeenCalled();
    });

    it('creates new closure with GENESIS_BLOCK if no previous day closure exists', async () => {
      (db.sync_events.count as any).mockResolvedValue(0);
      (db.financial_closures.get as any).mockResolvedValue(undefined);

      const result = await service.createDailyClosure(new Date('2026-06-10T15:00:00Z'), 'BR-1');
      
      expect(result.previousHash).toBe('GENESIS_BLOCK_0000000000000000');
      expect(db.financial_closures.put).toHaveBeenCalledWith(result);
      expect(mockUow.registerSync).toHaveBeenCalledWith('financial_closures', 'INSERT', result);
      expect(mockUow.registerAudit).toHaveBeenCalledWith('DAILY_CLOSURE', 'System', expect.any(String));
    });

    it('creates new closure with hash from previous day if it exists', async () => {
      (db.sync_events.count as any).mockResolvedValue(0);
      
      // Mock get to return undefined for today, but valid for yesterday
      (db.financial_closures.get as any).mockImplementation(async (id: string) => {
        if (id.includes('2026-06-09')) return { hash: 'HASH_YESTERDAY' };
        return undefined;
      });

      const result = await service.createDailyClosure(new Date('2026-06-10T15:00:00Z'), 'BR-1');
      
      expect(result.previousHash).toBe('HASH_YESTERDAY');
    });
  });

  describe('verifyChain', () => {
    it('returns valid for < 2 closures', async () => {
      (db.financial_closures.sortBy as any).mockResolvedValue([{ id: '1' }]);
      const result = await service.verifyChain('BR-1');
      expect(result.isValid).toBe(true);
    });

    it('returns invalid if previousHash mismatch', async () => {
      const cls = [
        { id: '1', hash: 'HASH_1' },
        { id: '2', previousHash: 'WRONG_HASH', summary: {} }
      ];
      (db.financial_closures.sortBy as any).mockResolvedValue(cls);

      const result = await service.verifyChain('BR-1');
      expect(result.isValid).toBe(false);
      expect(result.brokenLink).toBe('2');
    });

    it('returns invalid if current hash mismatch (tampered data)', async () => {
      const cls = [
        { id: '1', hash: 'HASH_1' },
        { id: '2', previousHash: 'HASH_1', hash: 'WRONG_CALCULATED_HASH', summary: {} }
      ];
      (db.financial_closures.sortBy as any).mockResolvedValue(cls);

      // crypto.subtle.digest returns 32-byte 0000s, so calculated hash is 0000...
      const result = await service.verifyChain('BR-1');
      expect(result.isValid).toBe(false);
      expect(result.brokenLink).toBe('2');
    });

    it('returns valid for proper chain', async () => {
      // Create a mocked valid chain
      const expectedHash = new Array(32).fill('00').join('');
      const cls = [
        { id: '1', hash: 'HASH_1' },
        { id: '2', previousHash: 'HASH_1', hash: expectedHash, summary: {} }
      ];
      (db.financial_closures.sortBy as any).mockResolvedValue(cls);

      const result = await service.verifyChain('BR-1');
      expect(result.isValid).toBe(true);
    });
  });

  describe('verifyAuditChain', () => {
    it('returns valid for < 2 logs', async () => {
      (db.audit_logs.toArray as any).mockResolvedValue([{ id: '1' }]);
      const result = await service.verifyAuditChain();
      expect(result.isValid).toBe(true);
    });

    it('returns invalid if previousHash mismatch and not GENESIS', async () => {
      const logs = [
        { id: '2', previousHash: 'WRONG_HASH' },
        { id: '1', hash: 'HASH_1' } // remember verifyAuditChain reverses!
      ];
      (db.audit_logs.toArray as any).mockResolvedValue(logs);
      
      const result = await service.verifyAuditChain();
      expect(result.isValid).toBe(false);
      expect(result.brokenLink).toBe('2');
    });

    it('returns valid if previousHash mismatch but is GENESIS', async () => {
      const logs = [
        { id: '2', previousHash: 'GENESIS_BLOCK_0000000000000000' },
        { id: '1', hash: 'HASH_1' } 
      ];
      (db.audit_logs.toArray as any).mockResolvedValue(logs);
      
      const result = await service.verifyAuditChain();
      expect(result.isValid).toBe(true);
    });
  });
});
