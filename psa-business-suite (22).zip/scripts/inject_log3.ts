import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'src/infrastructure/services/sync/SyncQueueManager.ts');
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace(
  /for \(const eventId of eventIds\) \{/,
  "console.log('INSIDE TX CALLBACK!'); for (const eventId of eventIds) {"
);

fs.writeFileSync(filePath, content, 'utf-8');
