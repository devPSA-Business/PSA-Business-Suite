import { describe, it, expect, vi, beforeEach } from 'vitest';
import { SyncConflictHandler } from '../../../src/infrastructure/services/sync/SyncConflictHandler';
import { db, SyncEvent } from '../../../src/shared/api/db';

vi.mock('../../../src/shared/api/db', () => ({
  db: {
    sync_events: { get: vi.fn(), delete: vi.fn(), update: vi.fn() },
    sync_dlq:    { add: vi.fn() },
    transaction: vi.fn(async (...args) => {
      const callback = args.pop();
      if (typeof callback === 'function') {
        return await callback();
      }
    }),
  }
}));

describe('SyncConflictHandler', () => {
  let handler: SyncConflictHandler;

  beforeEach(() => {
    handler = new SyncConflictHandler();
    vi.clearAllMocks();
  });

  describe('classifyFirestoreError', () => {
    it('classifies permission-denied as conflict', () => {
      expect(handler.classifyFirestoreError(Object.assign(new Error(''), { code: 'permission-denied' }))).toBe('conflict');
      expect(handler.classifyFirestoreError(Object.assign(new Error(''), { code: 'failed-precondition' }))).toBe('conflict');
    });

    it('classifies unavailable as transient', () => {
      expect(handler.classifyFirestoreError(Object.assign(new Error(''), { code: 'unavailable' }))).toBe('transient');
      expect(handler.classifyFirestoreError(Object.assign(new Error(''), { code: 'deadline-exceeded' }))).toBe('transient');
    });

    it('classifies unknown errors as unknown', () => {
      expect(handler.classifyFirestoreError('random-error')).toBe('unknown');
      expect(handler.classifyFirestoreError(undefined)).toBe('unknown');
    });
  });

  describe('moveToDeadLetterQueue', () => {
    it('moves event to sync_dlq and appends error_message with CONFLICT status', async () => {
      const mockEvent: SyncEvent = {
        id: 1,
        entity_type: 'stock',
        action: 'UPDATE',
        payload: { id: '123' },
        status: 'PENDING',
        timestamp: Date.now()
      };

      await handler.moveToDeadLetterQueue(mockEvent, 'Simulated Firestore Error', 'permission-denied');

      expect(db.sync_dlq.add).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 1,
          entity_type: 'stock',
          status: 'CONFLICT',
          error_message: '[DLQ:permission-denied] Simulated Firestore Error'
        })
      );
      
      expect(db.sync_events.delete).toHaveBeenCalledWith(1);
    });

    it('does nothing on delete if event.id is not defined', async () => {
      const mockEventNoId: SyncEvent = {
        entity_type: 'stock',
        action: 'UPDATE',
        payload: { id: '123' },
        status: 'PENDING',
        timestamp: Date.now()
      };

      await handler.moveToDeadLetterQueue(mockEventNoId, 'Error', 'permission-denied');

      expect(db.sync_dlq.add).toHaveBeenCalled();
      expect(db.sync_events.delete).not.toHaveBeenCalled();
    });
  });
});
