import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'src/infrastructure/services/sync/SyncUploaderService.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// replace upload method
content = content.replace(
  /async upload\(events: SyncEvent\[\]\): Promise<void> \{\n    const chunks: SyncEvent\[\]\[\] = \[\];/,
  "async upload(events: SyncEvent[]): Promise<void> {\nconsole.log('UPLOAD EVENTS LENGTH: ', events.length);\n    const chunks: SyncEvent[][] = [];"
);

fs.writeFileSync(filePath, content, 'utf-8');
