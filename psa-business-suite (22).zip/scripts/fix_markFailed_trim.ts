import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'src/infrastructure/services/sync/SyncQueueManager.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// add trimming to markFailed
content = content.replace(
  /const dlqEvent: SyncEvent = \{\n\s*\.\.\.event,\n\s*status: 'FAILED',\n\s*error_message: `\[DLQ:max-retries\] \$\{errorMessage\}`\n\s*\};/,
  "const dlqEvent: SyncEvent = {\n            ...event,\n            status: 'FAILED',\n            error_message: `[DLQ:max-retries] ${errorMessage}`\n          };\n          if (dlqEvent.payload && typeof dlqEvent.payload.photoBeforeBase64 === 'string') {\n             dlqEvent.payload.photoBeforeBase64 = '[TRIMMED_FOR_DLQ]';\n          }"
);

fs.writeFileSync(filePath, content, 'utf-8');
console.log('Fixed markFailed to trim photos.');
