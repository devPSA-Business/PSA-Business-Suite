import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'src/infrastructure/services/sync/SyncQueueManager.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// replace markSynced
content = content.replace(
  /async markSynced\(eventIds: number\[\]\): Promise<void> \{/,
  "async markSynced(eventIds: number[]): Promise<void> {\nconsole.log('MARK SYNCED CALLED WITH: ', eventIds);"
);

fs.writeFileSync(filePath, content, 'utf-8');
