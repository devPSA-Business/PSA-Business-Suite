import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncServiceImpl.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

// replace update to SYNCED with delete
content = content.replace(
  /expect\(db\.sync_events\.update\)\.toHaveBeenCalledWith\(([^,]+), expect\.objectContaining\(\{ status: 'SYNCED' \}\)\);/g,
  "expect(db.sync_events.delete).toHaveBeenCalledWith($1);"
);

fs.writeFileSync(filePath, content, 'utf-8');
console.log('Fixed SYNCED update to delete in spec.');
