export const isDevEnvironment = () => {
  return import.meta.env.DEV || import.meta.env.VITE_IS_PREVIEW === 'true' || import.meta.env.MODE === 'development';
};

export const isAuthorizedDev = (email?: string | null) => {
  return isDevEnvironment() && email === 'dev.psajewelry@gmail.com';
};
