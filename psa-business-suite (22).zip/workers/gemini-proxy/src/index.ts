export interface Env {
  GEMINI_API_KEY: string;
  ALLOWED_ORIGIN: string;
}

export default {
  async fetch(request: Request, env: Env, ctx: any): Promise<Response> {
    // 1. Handle CORS Preflight
    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: {
          "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
          "Access-Control-Allow-Methods": "POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Max-Age": "86400",
        },
      });
    }

    // 2. Only allow POST requests
    if (request.method !== "POST") {
      return new Response("Method not allowed", { status: 405 });
    }

    // 3. Forward request to Gemini API
    const url = new URL(request.url);
    // Remove the proxy prefix if any and construct the target URL
    const targetUrl = new URL(`https://generativelanguage.googleapis.com${url.pathname}${url.search}`);
    targetUrl.searchParams.set("key", env.GEMINI_API_KEY);

    try {
      const body = await request.text();
      
      const response = await fetch(targetUrl.toString(), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body
      });

      const data = await response.text();

      return new Response(data, {
        status: response.status,
        headers: {
          "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
          "Content-Type": "application/json",
        },
      });
    } catch (error: any) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: {
          "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*",
          "Content-Type": "application/json",
        },
      });
    }
  },
};
