import { execSync } from 'child_process';

console.log("=== REMOTE ORIGIN/MAIN FILE INDEX ===");
try {
  const remoteFiles = execSync('git ls-tree -r origin/main --name-only').toString().trim().split('\n');
  console.log(`Total files tracked on origin/main: ${remoteFiles.length}`);
  
  const filesOfInt = [
    'vercel.json',
    'storage.rules',
    'GatekeeperPage.tsx',
    '.nojekyll',
    'SyncRetryPolicy.ts',
    'dexieSettingsStorage.ts',
    'DevToolsOverlay.tsx'
  ];
  
  console.log("\nChecking specific files on remote origin/main:");
  filesOfInt.forEach(file => {
    const matched = remoteFiles.filter(rf => rf.includes(file));
    if (matched.length > 0) {
      console.log(`  - ${file}: FOUND as -> ${matched.join(', ')}`);
    } else {
      console.log(`  - ${file}: NOT FOUND on remote`);
    }
  });

  console.log("\nAll scripts folder files on origin/main:");
  const scriptFiles = remoteFiles.filter(rf => rf.startsWith('scripts/'));
  scriptFiles.forEach(sf => console.log(`  - ${sf}`));

} catch (e: any) {
  console.log("Error querying remote index:", e.message);
}
