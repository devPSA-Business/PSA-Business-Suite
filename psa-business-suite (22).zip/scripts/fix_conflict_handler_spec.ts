import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncConflictHandler.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace(
  /handler\.classifyFirestoreError\('permission-denied'\)/g,
  "handler.classifyFirestoreError({ code: 'permission-denied' } as any)"
);
content = content.replace(
  /handler\.classifyFirestoreError\('failed-precondition'\)/g,
  "handler.classifyFirestoreError({ code: 'failed-precondition' } as any)"
);
content = content.replace(
  /handler\.classifyFirestoreError\('unavailable'\)/g,
  "handler.classifyFirestoreError({ code: 'unavailable' } as any)"
);
content = content.replace(
  /handler\.classifyFirestoreError\('deadline-exceeded'\)/g,
  "handler.classifyFirestoreError({ code: 'deadline-exceeded' } as any)"
);

fs.writeFileSync(filePath, content, 'utf-8');
