import { create } from 'zustand';
import { UserRole } from '../../domain/models/User';
import type { User as FirebaseUser } from 'firebase/auth';

// FIX [CRITICAL-02]: Added branchId to AuthUser interface.
// Previously missing, causing SyncServiceImpl.enqueueSync() to always default to 'HQ'
// for all branch IDs — a critical multi-branch data isolation failure.
interface AuthUser {
  id: string;
  name: string;
  role: UserRole;
  branchId?: string; // FIXED: was present in interface but never populated at login
}

interface AuthState {
  user: AuthUser | null; // Local PIN-verified user
  firebaseUser: FirebaseUser | null; // Cloud-verified user
  isFirebaseInitialized: boolean;
  isFirebaseReady: boolean;
  login: (user: AuthUser) => void;
  logout: () => void;
  setFirebaseUser: (user: FirebaseUser | null) => void;
  setFirebaseReady: (status: boolean) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  firebaseUser: null,
  isFirebaseInitialized: false,
  isFirebaseReady: false,
  setFirebaseUser: (firebaseUser) => set({ firebaseUser, isFirebaseInitialized: true }),
  setFirebaseReady: (status) => set({ isFirebaseReady: status }),
  login: (user) => set({ user }),
  logout: () => set({ user: null }),
}));
