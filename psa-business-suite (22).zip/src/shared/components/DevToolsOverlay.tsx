import React, { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { useSecurityStore } from '../store/useSecurityStore';
import { db } from '../api/db';
import { Database, RefreshCcw, LogOut, Beaker, ChevronRight, ArrowLeft, ArrowRight, Home, Trash2 } from 'lucide-react';
import { UserRole } from '../../domain/models/User';
import { useNavigate, useRouter } from '@tanstack/react-router';
import { isDevEnvironment } from '../utils/devUtils';
import { useToastStore } from '../store/toastStore';

export const DevToolsOverlay = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, login, logout } = useAuthStore();
  const { addToast } = useToastStore();
  const navigate = useNavigate();
  const router = useRouter();

  // Hanya tampilkan jika berada dalam environment developer/preview
  if (!isDevEnvironment()) return null;

  // Jangan tampilkan di halaman login
  if (!user) return null;

  const handleRoleSwitch = (role: UserRole) => {
    login({
      id: user.id || 'dev-id',
      name: user.name || 'Dev User',
      branchId: user.branchId || 'HQ',
      role: role,
    });
    addToast(`[DEV] Peran dialihkan ke: ${role}`, 'info');
    navigate({ to: '/' });
  };

  const handleSeedData = async () => {
    try {
      addToast('[DEV] Menyuntikkan data sampel...', 'info');
      const { seedDatabase } = await import('../../lib/seeder');
      await seedDatabase();
      addToast('[DEV] Data sampel berhasil disuntikkan.', 'success');
      window.location.reload();
    } catch (_e) {
      addToast('[DEV] Gagal menyuntikkan data.', 'error');
    }
  };

  const handleClearDb = async () => {
    try {
      await db.delete();
      await db.open();
      useSecurityStore.setState({ isSetupComplete: false, isPinVerified: false });
      logout();
      addToast('[DEV] Database IndexedDB berhasil dihapus.', 'warning');
      window.location.href = '/';
    } catch (_e) {
      addToast('[DEV] Gagal menghapus database.', 'error');
    }
  };

  const handleClearCache = () => {
    localStorage.clear();
    sessionStorage.clear();
    addToast('[DEV] Local Storage & Session Storage dibersihkan.', 'warning');
    window.location.reload();
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-4 z-[9999] bg-stone-900 border border-stone-700 text-stone-100 p-3 rounded-full shadow-2xl hover:bg-stone-800 hover:scale-110 active:scale-95 transition-all flex items-center justify-center group"
      >
        <Beaker size={24} className="text-amber-500 animate-pulse group-hover:animate-none" />
      </button>
    );
  }

  return (
    <div className="fixed bottom-24 right-4 z-[9999] bg-stone-900 border border-stone-700 shadow-2xl rounded-2xl w-72 flex flex-col p-4 animate-in slide-in-from-bottom-5 fade-in duration-200" style={{ maxHeight: 'calc(100vh - 120px)', overflowY: 'auto' }}>
      <div className="flex items-center justify-between border-b border-stone-800 pb-3 mb-3">
        <div className="flex items-center gap-2 text-amber-500 font-bold whitespace-nowrap">
          <Beaker size={18} />
          <span>DEV SANDBOX MODULE</span>
        </div>
        <button
          onClick={() => setIsOpen(false)}
          className="text-stone-400 hover:text-white p-1 rounded-md bg-stone-800 hover:bg-stone-700 transition-colors"
        >
          <ChevronRight size={18} />
        </button>
      </div>

      <div className="space-y-4">
        {/* NAVIGASI CEPAT */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-stone-500 tracking-wider">NAVIGASI CEPAT</h4>
          <div className="flex gap-2">
            <button
              onClick={() => router.history.back()}
              className="flex-1 py-2 flex items-center justify-center bg-stone-800 border border-stone-700 text-stone-300 rounded-lg hover:bg-stone-700 hover:text-white transition-colors"
              title="Kembali"
            >
              <ArrowLeft size={16} />
            </button>
            <button
              onClick={() => navigate({ to: '/' })}
              className="flex-1 py-2 flex flex-col items-center justify-center bg-stone-800 border border-stone-700 text-stone-300 rounded-lg hover:bg-stone-700 hover:text-white transition-colors"
              title="Beranda"
            >
              <Home size={16} />
            </button>
            <button
              onClick={() => router.history.forward()}
              className="flex-1 py-2 flex items-center justify-center bg-stone-800 border border-stone-700 text-stone-300 rounded-lg hover:bg-stone-700 hover:text-white transition-colors"
              title="Maju"
            >
              <ArrowRight size={16} />
            </button>
          </div>
        </div>

        {/* ROLE SIMULATION */}
        <div className="space-y-2 pt-2 border-t border-stone-800">
          <h4 className="text-xs font-bold text-stone-500 tracking-wider">SIMULASI RBAC (Role)</h4>
          <div className="grid grid-cols-2 gap-2">
            {[UserRole.ADMIN, UserRole.MANAGER, UserRole.CASHIER].map((role) => (
              <button
                key={role}
                onClick={() => handleRoleSwitch(role)}
                className={`py-1.5 px-2 text-xs font-bold rounded-lg border transition-colors ${
                  user.role === role
                    ? 'bg-amber-500/20 border-amber-500 text-amber-500'
                    : 'bg-stone-800 border-stone-700 text-stone-300 hover:bg-stone-700 hover:text-white'
                }`}
              >
                {role}
              </button>
            ))}
          </div>
        </div>

        {/* DATA UTILITIES */}
        <div className="space-y-2 pt-2 border-t border-stone-800">
          <h4 className="text-xs font-bold text-stone-500 tracking-wider">UTILITAS DATA</h4>
          <button
            onClick={handleSeedData}
            className="w-full flex items-center justify-start gap-3 py-2 px-3 text-sm font-medium bg-stone-800 border border-stone-700 text-stone-300 rounded-lg hover:bg-stone-700 hover:text-white transition-colors"
          >
            <Database size={16} className="text-emerald-500" />
            Isi Data Sampel
          </button>
          <button
            onClick={handleClearCache}
            className="w-full flex items-center justify-start gap-3 py-2 px-3 text-sm font-medium bg-stone-800 border border-stone-700 text-stone-300 rounded-lg hover:bg-stone-700 text-amber-400 hover:bg-amber-900/30 transition-colors"
          >
            <Trash2 size={16} className="text-amber-500" />
            Clear Storage (Cache)
          </button>
          <button
            onClick={handleClearDb}
            className="w-full flex items-center justify-start gap-3 py-2 px-3 text-sm font-medium bg-stone-800 border border-stone-700 text-stone-300 rounded-lg hover:bg-stone-700 text-red-400 hover:bg-red-900/30 transition-colors"
          >
            <RefreshCcw size={16} className="text-red-500" />
            Nuke Database (Reset)
          </button>
        </div>

        {/* QUICK LOGOUT */}
        <div className="pt-2 border-t border-stone-800">
          <button
            onClick={() => {
              logout();
              useSecurityStore.setState({ isPinVerified: false });
              window.location.href = '/';
            }}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 text-sm font-bold bg-stone-800 border border-stone-700 text-stone-300 rounded-lg hover:bg-stone-700 hover:text-white transition-colors"
          >
            <LogOut size={16} />
            Quick Logout
          </button>
        </div>
      </div>
    </div>
  );
};

