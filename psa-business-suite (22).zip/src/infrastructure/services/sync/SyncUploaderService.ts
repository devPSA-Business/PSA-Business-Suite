/**
 * @ai_context Menangani upload batch event ke Firestore dengan retry exponential dan DLQ fallback.
 * @security_tier HIGH
 * @business_rule Semua write ke Firestore WAJIB melalui service ini, bukan dari UI langsung.
 *                Foto Base64 > 2MB wajib diupload ke Firebase Storage sebelum di-set ke Firestore.
 * @data-component-id: sync-uploader-service
 * @data-error-domain: sync
 * @changelog:
 *   2026-05-20 — P2: Integrasi classifyFirestoreError + moveToDeadLetterQueue dari SyncConflictHandler
 *                    permission-denied → DLQ (bukan retry loop), type-safe tanpa 'any'
 *              — P4: Ganti semua 'any' dengan unknown + type narrowing
 */
import { db, SyncEvent } from '../../../shared/api/db';
import {
  firestoreDb,
  safeFirestoreCall,
} from '../../../shared/api/firebase';
import {
  WriteBatch,
  DocumentReference,
  writeBatch,
  doc,
  collection,
  increment,
  updateDoc,
  setDoc,
  deleteDoc,
} from 'firebase/firestore';
import { logger } from '../../../lib/logger';
import { SyncQueueManager } from './SyncQueueManager';
import { SyncConflictHandler } from './SyncConflictHandler';

const CHUNK_SIZE = 50;

/** Type guard: memastikan nilai adalah Record yang bisa diindeks */
function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** Bersihkan undefined dari object payload sebelum dikirim ke Firestore */
function stripUndefined(obj: unknown): unknown {
  return JSON.parse(JSON.stringify(obj));
}

/** Ekstrak kode error Firestore dari error unknown */
function extractFirestoreCode(error: unknown): string {
  if (!isRecord(error)) return '';
  const code = error['code'];
  return typeof code === 'string' ? code : '';
}

export class SyncUploaderService {
  constructor(
    private readonly queueManager: SyncQueueManager,
    private readonly conflictHandler: SyncConflictHandler,
    private readonly onAuthError: () => void
  ) {}

  /** Upload semua executable events ke Firestore dalam chunks. */
  async upload(events: SyncEvent[]): Promise<void> {
    const chunks: SyncEvent[][] = [];
    for (let i = 0; i < events.length; i += CHUNK_SIZE) {
      chunks.push(events.slice(i, i + CHUNK_SIZE));
    }
    for (const chunk of chunks) {
      await this._processChunk(chunk);
    }
  }

  private async _processChunk(chunk: SyncEvent[]): Promise<void> {
    // Pre-fetch server docs untuk conflict detection (solusi N+1 problem)
    const serverDocsMap = await this.conflictHandler.prefetchServerDocs(chunk);

    const batch = writeBatch(firestoreDb);
    const individualOps: { eventId: number; op: () => Promise<void> }[] = [];
    const conflictEvents: { eventId: number; serverPayload: unknown }[] = [];

    for (const event of chunk) {
      if (!event.id) continue;

      const collectionRef = collection(firestoreDb, event.entity_type);
      const docId = event.payload?.client_txn_id
        ? String(event.payload.client_txn_id)
        : event.payload?.id
          ? String(event.payload.id)
          : String(event.id);
      const docRef = doc(collectionRef, docId);

      // Conflict detection via CRDT version
      if (event.id && serverDocsMap.has(event.id)) {
        const serverData = serverDocsMap.get(event.id);
        if (this.conflictHandler.hasConflict(event, serverData)) {
          conflictEvents.push({ eventId: event.id, serverPayload: serverData });
          continue;
        }
      }

      // Foto Base64 → Firebase Storage (repair images)
      if (event.entity_type === 'repair_services' && event.payload.photoBeforeBase64) {
        const uploaded = await this._uploadRepairPhoto(event);
        if (!uploaded) continue;
      }

      this._addToBatch(batch, individualOps, event, docRef);
    }

    if (conflictEvents.length > 0) {
      await this.queueManager.markConflict(conflictEvents);
    }

    if (individualOps.length === 0) return;

    // Jeda kecil agar GC bisa berjalan sebelum commit
    await new Promise<void>((r) => setTimeout(r, 50));

    await this._commitBatch(batch, individualOps, chunk);
  }

  private _addToBatch(
    batch: WriteBatch,
    individualOps: { eventId: number; op: () => Promise<void> }[],
    event: SyncEvent,
    docRef: DocumentReference
  ): void {
    const eventId = event.id!;

    if (
      event.action === 'UPDATE_DELTA' &&
      event.payload.delta_field &&
      event.payload.delta_value !== undefined
    ) {
      const change = Number(event.payload.delta_value);
      const field = String(event.payload.delta_field);
      if (!isNaN(change)) {
        const updateData: Record<string, unknown> = { ...event.payload };
        delete updateData['delta_field'];
        delete updateData['delta_value'];
        updateData[field] = increment(change);
        batch.update(docRef, updateData);
        individualOps.push({ eventId, op: async () => { await updateDoc(docRef, updateData); } });
      }
    } else if (
      event.entity_type === 'stock' &&
      event.action === 'UPDATE' &&
      event.payload.quantityChange !== undefined
    ) {
      // Backward compatibility untuk event stock lama
      const change = Number(event.payload.quantityChange);
      if (!isNaN(change)) {
        const updateData: Record<string, unknown> = { ...event.payload };
        delete updateData['quantityChange'];
        updateData['quantity'] = increment(change);
        batch.update(docRef, updateData);
        individualOps.push({ eventId, op: async () => { await updateDoc(docRef, updateData); } });
      }
    } else if (event.action === 'INSERT' || event.action === 'UPDATE') {
      const rawPayload = stripUndefined(event.payload) as Record<string, unknown>;
      // CRDT: Inject version field jika belum ada.
      // INSERT → version = timestamp enqueue (monotonic clock per device).
      // UPDATE → increment version dari payload; jika tidak ada, pakai Date.now().
      // Ini memungkinkan SyncConflictHandler.hasConflict() mendeteksi konflik dengan akurat.
      if (!rawPayload['version']) {
        rawPayload['version'] = event.action === 'INSERT'
          ? event.timestamp  // waktu enqueue original, lebih stabil dari Date.now()
          : Date.now();
      }
      const safePayload = rawPayload;
      batch.set(docRef, safePayload, { merge: true });
      individualOps.push({ eventId, op: async () => { await setDoc(docRef, safePayload, { merge: true }); } });
    } else if (event.action === 'DELETE') {
      batch.delete(docRef);
      individualOps.push({ eventId, op: async () => { await deleteDoc(docRef); } });
    }
  }

  private async _commitBatch(
    batch: WriteBatch,
    individualOps: { eventId: number; op: () => Promise<void> }[],
    chunk: SyncEvent[]
  ): Promise<void> {
    try {
      await safeFirestoreCall(async () => { await batch.commit(); });
      await this.queueManager.markSynced(individualOps.map((o) => o.eventId));
    } catch (error) {
      logger.warn('[SyncUploaderService] Batch commit gagal, fallback ke individual writes.', error);
      const errCode = extractFirestoreCode(error);
      if (errCode === 'unauthenticated') {
        this.onAuthError();
        return;
      }
      await this._fallbackIndividualWrites(individualOps, chunk);
    }
  }

  private async _fallbackIndividualWrites(
    individualOps: { eventId: number; op: () => Promise<void> }[],
    chunk: SyncEvent[]
  ): Promise<void> {
    const results = await Promise.allSettled(
      individualOps.map((o) => safeFirestoreCall(o.op))
    );

    for (let i = 0; i < results.length; i++) {
      const result = results[i];
      const eventId = individualOps[i].eventId;

      if (result.status === 'fulfilled') {
        await this.queueManager.markSynced([eventId]);
      } else {
        const errorObj: unknown = result.reason;
        const errorMessage = errorObj instanceof Error ? errorObj.message : String(errorObj);
        const errCode = extractFirestoreCode(errorObj);

        if (errCode === 'unauthenticated') {
          this.onAuthError();
          return;
        }

        const currentEvent = chunk.find((e) => e.id === eventId);

        // P2 Remediation: permission-denied / CRDT reject → DLQ (bukan retry)
        if (currentEvent) {
          const errorClass = this.conflictHandler.classifyFirestoreError(errorObj);
          if (errorClass === 'conflict') {
            logger.warn(
              `[SyncUploaderService] Event ${eventId} (${currentEvent.entity_type}) ditolak Firestore — dipindahkan ke DLQ`,
              { errCode, errorMessage }
            );
            await this.conflictHandler.moveToDeadLetterQueue(
              currentEvent,
              errorObj,
              errCode || 'conflict'
            );
            continue; // Tidak perlu markFailed — event sudah di DLQ
          }
        }

        await this.queueManager.markFailed(eventId, errorMessage, currentEvent);
      }
    }
  }

  /** Upload foto Base64 ke Firebase Storage; update payload event in-place. Returns true jika sukses. */
  private async _uploadRepairPhoto(event: SyncEvent): Promise<boolean> {
    try {
      const { storage } = await import('../../../shared/api/firebase');
      const { ref, uploadString, getDownloadURL } = await import('firebase/storage');

      if (!storage) throw new Error('Firebase Storage not initialized');

      const raw = event.payload.photoBeforeBase64 as string;
      const base64Data = raw.includes(',') ? raw.split(',')[1] : raw;

      if (base64Data.length > 3_000_000) {
        throw new Error('Ukuran foto terlalu besar (> 2MB).');
      }

      const docId = event.payload?.client_txn_id
        ? String(event.payload.client_txn_id)
        : event.payload?.id
          ? String(event.payload.id)
          : String(event.id);
      const imageRef = ref(storage, `repairs/${docId}_before_${Date.now()}.jpg`);
      await uploadString(imageRef, base64Data, 'base64');
      const downloadUrl = await getDownloadURL(imageRef);

      event.payload.photoBeforeUrl = downloadUrl;
      delete event.payload.photoBeforeBase64;
      return true;
    } catch (imgError) {
      logger.error('[SyncUploaderService] Gagal upload foto reparasi', imgError);
      await db.sync_events.update(event.id!, {
        status: 'FAILED',
        error_message: 'Gagal upload foto: ' + (imgError instanceof Error ? imgError.message : String(imgError)),
        next_retry_time: Date.now() + 60_000,
      });
      return false;
    }
  }
}
