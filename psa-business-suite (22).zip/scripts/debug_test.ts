import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'tests/unit/sync/SyncServiceImpl.spec.ts');
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace("await syncService.processSyncQueue();", 
  "const spy = vi.spyOn(console, 'error');\n      await syncService.processSyncQueue();\n      if(spy.mock.calls.length > 0) throw new Error(JSON.stringify(spy.mock.calls));\n      spy.mockRestore();");

fs.writeFileSync(filePath, content, 'utf-8');
