import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'src/infrastructure/services/sync/SyncQueueManager.ts');
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace(/import \{ logger \} from '\.\.\/\.\.\/\.\.\/lib\/logger';\n/, '');

fs.writeFileSync(filePath, content, 'utf-8');

const conflictPath = path.join(process.cwd(), 'src/infrastructure/services/sync/SyncConflictHandler.ts');
let conflictContent = fs.readFileSync(conflictPath, 'utf-8');
conflictContent = conflictContent.replace(/export interface ConflictPayload \{\n  serverVersion\?: number;\n  serverId\?: string;\n  \[key: string\]: any;\n\}\n/, '');
fs.writeFileSync(conflictPath, conflictContent, 'utf-8');
